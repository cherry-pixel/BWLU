import { Routes } from '@angular/router';

import { DashboardComponent } from '../../pages/dashboard/dashboard.component';
import { IconsComponent } from '../../pages/events/events.component';
import { MapsComponent } from '../../pages/skills/skills.component';
import { UserProfileComponent } from '../../pages/user-profile/user-profile.component';
import { TablesComponent } from '../../pages/groups/groups.component';

export const AdminLayoutRoutes: Routes = [
    { path: 'dashboard',      component: DashboardComponent },
    { path: 'user-profile',   component: UserProfileComponent },
    { path: 'groups',         component: TablesComponent },
    { path: 'events',          component: IconsComponent },
    { path: 'skills',           component: MapsComponent }
];
